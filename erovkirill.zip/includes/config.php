<?php
/**
 * Конфигурация сайта для хостинга
 * Настройте эти параметры под ваш хостинг
 */

// Настройки базы данных
define('DB_HOST', 'localhost');          // Обычно localhost
define('DB_NAME', 'uchitsya_portal');    // Имя вашей БД на хостинге
define('DB_USER', 'username');           // Имя пользователя БД
define('DB_PASS', 'password');           // Пароль БД

// Настройки сайта
define('SITE_URL', 'https://yourdomain.com'); // Ваш домен
define('SITE_NAME', 'Учиться.net');
define('SITE_EMAIL', 'info@yourdomain.com');

// Настройки сессии
define('SESSION_LIFETIME', 86400); // 24 часа

// Режим отладки (true для разработки, false для продакшена)
define('DEBUG_MODE', false);

// Кодировка
define('CHARSET', 'UTF-8');
define('TIMEZONE', 'Europe/Moscow');
?>