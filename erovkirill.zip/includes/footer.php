    </main>
    
    <footer class="site-footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="logo">
                        <i class="fas fa-graduation-cap"></i>
                        <span>Учиться<span class="logo-net">.net</span></span>
                    </div>
                    <p>Портал дополнительного профессионального образования. Мы помогаем расти профессионально с 2024 года.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-vk"></i></a>
                        <a href="#"><i class="fab fa-telegram"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="footer-section">
                    <h4>Навигация</h4>
                    <ul>
                        <li><a href="/uchitsya.net/index.php">Главная</a></li>
                        <li><a href="#">Каталог курсов</a></li>
                        <li><a href="#">Для корпоративных клиентов</a></li>
                        <li><a href="#">Преподавателям</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Помощь</h4>
                    <ul>
                        <li><a href="#">Частые вопросы</a></li>
                        <li><a href="#">Техническая поддержка</a></li>
                        <li><a href="#">Документы</a></li>
                        <li><a href="#">Контакты</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Контакты</h4>
                    <ul class="contact-info">
                        <li><i class="fas fa-envelope"></i> info@uchitsya.net</li>
                        <li><i class="fas fa-phone"></i> 8 (800) 123-45-67</li>
                        <li><i class="fas fa-map-marker-alt"></i> Москва, ул. Образования, 15</li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 Портал «Учиться.net». Все права защищены.</p>
                <p><a href="#">Политика конфиденциальности</a> | <a href="#">Пользовательское соглашение</a></p>
            </div>
        </div>
    </footer>
    
    <script>
        // Простой JavaScript для мобильного меню (можно доработать)
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Портал "Учиться.net" загружен!');
        });
    </script>
</body>
</html>