<?php 
// Подключаем инициализацию
require_once 'init.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Портал «Учиться.net»</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <style>
        body { margin: 0; padding: 0; }
        .site-header { background: #2c3e50; padding: 15px 0; }
        .header-container { max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; padding: 0 20px; }
        .logo a { color: white; text-decoration: none; font-size: 24px; font-weight: bold; display: flex; align-items: center; gap: 10px; }
        .logo-net { color: #3498db; }
        .main-nav ul { list-style: none; display: flex; gap: 20px; margin: 0; padding: 0; }
        .main-nav a { color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px; transition: background 0.3s; }
        .main-nav a:hover { background: rgba(255,255,255,0.1); }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
    </style>
</head>
<body>
    <header class="site-header">
        <div class="header-container">
            <div class="logo">
                <a href="index.php">
                    <i class="fas fa-graduation-cap"></i>
                    <span>Учиться<span class="logo-net">.net</span></span>
                </a>
            </div>
            
            <nav class="main-nav">
                <ul>
                    <!-- Упрощаем навигацию -->
<?php if(isset($_SESSION['user_id'])): ?>
    <li><a href="index.php">Главная</a></li>
    <li><a href="personal.php">Личный кабинет</a></li>
    <li><a href="create_application.php">Подать заявку</a></li>
    <li><a href="logout.php">Выйти</a></li>
<?php else: ?>
    <li><a href="index.php">Главная</a></li>
    <li><a href="login.php">Войти</a></li>
    <li><a href="register.php">Регистрация</a></li>
<?php endif; ?>
                    
                </ul>
            </nav>
        </div>
    </header>
    
    <main class="container">