<?php
// Безопасный запуск сессии
if (session_status() === PHP_SESSION_NONE) {
    // Настройки безопасности сессии
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_secure', 1); // Для HTTPS
    
    session_start();
    
    // Регенерация ID сессии для безопасности
    if (!isset($_SESSION['created'])) {
        $_SESSION['created'] = time();
    } else if (time() - $_SESSION['created'] > 1800) { // 30 минут
        session_regenerate_id(true);
        $_SESSION['created'] = time();
    }
}

// Настройка временной зоны
date_default_timezone_set(TIMEZONE);

// Настройки ошибок в зависимости от режима
if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
}

// Заголовки безопасности
header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1; mode=block");
header("Referrer-Policy: strict-origin-when-cross-origin");

// Кодировка
header('Content-Type: text/html; charset=' . CHARSET);

// Запрет кэширования (для динамических страниц)
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>