<?php
/**
 * Функции безопасности
 */

// Защита от XSS
function clean_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

// Валидация email
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Валидация телефона
function validate_phone($phone) {
    return preg_match('/^8\(\d{3}\)\d{3}-\d{2}-\d{2}$/', $phone);
}

// Валидация пароля
function validate_password($password) {
    return strlen($password) >= 8;
}

// Генерация CSRF токена
function generate_csrf_token() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Проверка CSRF токена
function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Логирование действий
function log_action($action, $user_id = null, $details = '') {
    $log_file = __DIR__ . '/../logs/actions.log';
    $timestamp = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
    
    $log_entry = "[$timestamp] [$ip] [User: $user_id] [$action] $details\n";
    
    // Создаем папку logs если её нет
    if (!is_dir(dirname($log_file))) {
        mkdir(dirname($log_file), 0755, true);
    }
    
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
}
?>